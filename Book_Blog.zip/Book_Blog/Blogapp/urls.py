from django.urls import path
from . import views

urlpatterns = [
    path('index/',views.index),
    path('book_blog/', views.book_blog),
    path('',views.landing_page),
    path('login/', views.user_login),
    path('signup/', views.signup),
    path('homepage/', views.homepage),
    path('Genres/',views.Genres),
    path('Mystery/' ,views.Mystery),
    path('logout/', views.user_logout),
    path('newbook/',views.book_create_view),
    path('feedback/',views.feedback),
    path('books/', views.allbook),
    path('book/<int:id>/', views.book_view),
    path('book/<int:id>/delete/', views.book_delete),
    path('book/<int:id>/edit/', views.book_update),
    path('authors/', views.author_view),
    path('author/<int:id>/', views.author_detail),
]
    
 
