from django import forms
from .models import Book, Author

class LoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)


class BookForm(forms.ModelForm):
    class Meta:
        model = Book  # Specify the model associated with the form
        fields = ['title','author', 'Description','publication_date' ]  # Define the fields to include in the form


class AuthorForm(forms.ModelForm):
    class Meta:
        model = Author
        fields = ['name', 'biography']


class Feedback(forms.Form):
    Email = forms.EmailField()
    
    def str(self):
        return self.Email